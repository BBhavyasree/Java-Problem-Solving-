public class Overloading3 {
    
    Overloading3() {
        System.out.println("Default Constructor "); 
        
    }

    
    Overloading3(int a) {
       System.out.println("a="+a); 
    }

   
    Overloading3(int a, int b) { 
        System.out.println("a="+a+" b = "+b);
        
    }

    
}

public class Main{
    public static void main(String[] args) {
       Overloading3 ob = new Overloading3() ; 
       Overloading3 ob = new Overloading3(256) ; 
       Overloading3 ob = new Overloading3(1000, 2000) ; 
       

        
    }
}

