/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util. * ; 
import java.lang.Math;

public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt(); 
	     

	        int d =n % 10 ;                                 // d  123 % 10 == 3
	       // int y = n%100;
	         
	        n = n /10 ;
	        boolean flag = true ; 
	        while (n > 0 ) { 
	            int d1 = n% 10 ;
	            if (Math.abs (d1 -d )!= 1) { 
	                flag = false ;
	                
	                break ;
	            }
	                d =  d1  ; 
	                n =n/10;
	       
	            
	        }
	        if (flag) { 
	            System.out.println ("Jumping Number") ;
	        } 
	        else { 
	            System.out.println("Not a Jumping Number");
	        } 
	        
	        
	       
	        
	    //for ()
	//	System.out.println("Hello World");
	
}
    
}
 
 

