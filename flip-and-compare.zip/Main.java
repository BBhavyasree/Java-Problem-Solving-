import java.util.*;

public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int p1 = sc.nextInt();
		int p2 = sc.nextInt();
		int s1 =0;
		int s2  = 0;

		while(p1>0) {
			int d =p1%10;
			s1 = s1 *10 +d;
			p1 = p1/10;

		}
		System.out.println(s1);


		while (p2> 0) {
			int d  = p2 %10;
			s2 = s2 *10 +d;
			p2 = p2/10 ;

		}
		System.out.println(s2 );


		if ( s1 > s2  )
		{
			System.out.println("s1 is the Largest ");
		}
		else {
			System.out.println ("s2  is the Largest ");
		}
	}
}



