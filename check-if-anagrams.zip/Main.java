import java.util.*; 
import java.lang.*; 

public class Main {
    public static void main(String[] args) { 
        Scanner sc = new Scanner(System.in); 
        String str1  = sc.nextLine();  
        String str2   = sc.nextLine();
          char[] arr = str1.toCharArray();   
          Arrays.sort(arr) ;  
          String  sortarr = new String (arr) ; 
          
          
        String result = "";   
        char []  arr1 = str2.toCharArray() ;  
        Arrays.sort(arr1 ) ;
        String sortarr1 = new String (arr1 ) ; 
        
     
    
        
        
        if(str1.length() != str2.length() ) {  
            System.out.println("Not Equal ") ; 
        } 
        else { 
            
            if (sortarr1.equals(sortarr) )  { 
                System.out.println("They are Anagrams ") ; 
                
            } 
            else {
                System.out.println("Not an Anagram ") ; 
                
            }
        } 
   

}
} 

