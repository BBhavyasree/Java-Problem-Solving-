// In a given Number, find the Difference between the even and the Odd Numbers. 
//EX: 123456 ==> 246 - 135 = ? 
import java.util.*;



public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Enter a Number ");
	    int a = sc.nextInt();
	   /* int k=0;
	    for(int i=0; i <= a; i++) {
	        if (i%2 ==0){
	             k =i;
	            System.out.println(k);
	        }
	        a = a/10;
	        
	    }*/
	    digit =a%10;
	    sum =sum*10+digit;
	    System.out.println(sum);
	    
	    
		
	}
}
