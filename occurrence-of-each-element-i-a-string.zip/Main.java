/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/ 
import java.util.* ; 
import java.lang.* ; 

public class Main
{
	public static void main(String[] args) { 
	    String s = "apple" ; 
	    int [] count = new int [256 ] ; 
	    for (int i =0 ; i<s.length () ; i++) { 
	        char c = s.charAt(i) ; 
	        count[c] ++ ; 
	    } 
	    
	    boolean [] printed = new boolean [256 ] ; 
	     for (int i = 0 ; i < s.length (); i++) { 
	         char c = s.charAt(i) ; 
	         if ( !printed [c] ) { 
	             System.out.println(c + ":" + count [c] ) ; 
	             printed [c] = true  ; 
	             
		//System.out.println("Hello World");
	}
} 
} 
} 

