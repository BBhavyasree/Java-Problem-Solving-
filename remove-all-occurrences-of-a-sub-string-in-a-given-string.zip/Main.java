/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/ 
import java.util.* ; 
import java.lang.* ; 

public class Main  
{
	public static void main(String[] args) { 
	    Scanner sc = new Scanner (System.in) ; 
	    String str = sc.nextLine(); 
	    String ss = sc.nextLine() ;  
	    String result = "" ; 
	    
	    
	 
	    
	    int i = 0 ;  
	    while (i <= str.length () - ss.length () ) { 
	        if ( str.substring (i, i+ ss.length()).equals(ss)) { 
	            i += ss.length () ; 
	        } 
	        else { 
	            result += str.charAt(i) ; 
	            i++ ; 
	        } 
	    } 
	    while ( i < str.length ()) { 
	        result += str.charAt(i++) ; 
	    } 
	    
	    
	    
		System.out.println(str); 
		System.out.println(result ); 
		// System.out.println(max );
	}

}
