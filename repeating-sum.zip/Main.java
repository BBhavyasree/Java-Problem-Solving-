/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util. *;

public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Do you  ");
	    char ch = sc.next().charAt(0);
	    while(ch =='Y'||ch=='y'){
	        
	    
	        int a = sc.nextInt();
	        int b= sc.nextInt();
	        int Sum = a+b;
	        System.out.println("Sum is:"+ Sum);
	        System.out.println("Do you Want To Repeat "); 
	        ch = sc.next().charAt(0);
		
	}
}
}
