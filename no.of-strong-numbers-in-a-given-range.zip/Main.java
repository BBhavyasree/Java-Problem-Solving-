/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Main
{
	public static void main(String[] args) {
	    Scanner sc =new Scanner(System.in);
	    
	    
	    int start =sc.nextInt();
	    int end =sc.nextInt();
	    for(int i= start; i <=end; i++){
	        
	    
	    
	      int sum =0,  n= 1,  temp =i;
	      
	    
	    
	    
	    while(n>0){
	        int f=1;
	       int d =n%10;
	        for( i=1; i<=d; i++){
	            //int f=1;
	            f =f*i;
	            
	            
	        }sum+=f;
	        
	        n=n/10;
	   }//s = s+sum;
	   if(sum ==temp){
	       System.out.println(temp);
	       
	   }/*else{
	       System.out.println("No");
	   }*/
	       
	    
	//	System.out.println(sum);
	}
}
}
