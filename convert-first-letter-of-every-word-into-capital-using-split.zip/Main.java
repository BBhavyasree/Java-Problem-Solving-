    import java.util.*; 
    import java.lang.*; 

    public class Main {
        public static void main(String[] args) { 
            Scanner sc = new Scanner(System.in); 
            String str = sc.nextLine(); 
            String[] arr = str.split(" ");   // Split into words
            StringBuilder result = new StringBuilder(); 
            
            for (String w : arr) { 
                if (!w.isEmpty()) { 
                    char f = Character.toUpperCase(w.charAt(0)); // first letter uppercase
                    String l = w.substring(1).toLowerCase();     // rest lowercase
                    result.append(f).append(l).append(" ");
                }
            }

            System.out.println(result.toString().trim()); // Trim to remove last space
        }
    }
