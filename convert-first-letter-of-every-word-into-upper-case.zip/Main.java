import java.util.*; 
import java.lang.*; 

public class Main {
    public static void main(String[] args) { 
        Scanner sc = new Scanner(System.in); 
        String str = sc.nextLine(); 
        char[] arr = str.toCharArray();  
        String result = ""; 
        
        for (int i = 0; i < arr.length; i++) { 
            char ch = arr[i];  
            
            if (ch == ' ') {
                result += ch; // keep space as it is
            } else if (i == 0 || arr[i - 1] == ' ') {
                result += Character.toUpperCase(ch); // first letter of word
            } else {
                result += Character.toLowerCase(ch); // rest in lowercase
            }
            
        }

        System.out.println(result);
    }
}
