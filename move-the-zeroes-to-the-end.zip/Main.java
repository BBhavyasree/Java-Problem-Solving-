/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.* ;

public class Main
{
	public static void endZeroes(int n, int arr[]) {
		int temp ;
		int [] result = new int[n];
		int index = 0 ;


		for(int i =0; i<n; i++) {
			//for(int j=1; j<n ; j++)  {
			if ( arr[i] ==0) {
				/*temp = arr[i];
				arr[i] = arr[j] ;
				arr[j] = temp ; */
				result[index++] = arr[i] ;

			}
			if (arr[i] != 0)  { 
			    
			// }
		}
	}
	public static void main(String [] args ) {
		Scanner sc = new Scanner(System.in) ;
		int n = sc.nextInt() ;
		int result []= new int[n] ;

		int arr[]= new int [n] ;
		for(int i =0; i < n ; i ++)  {
			arr[i] = sc.nextInt() ;

		}
		endZeroes(n, arr) ;


		System.out.print(Arrays.toString (result));
	}
}

