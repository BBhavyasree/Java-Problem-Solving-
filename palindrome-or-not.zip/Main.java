/* TWO POINTER APPROACH 
        REDUCES TIME COMPLEXITY  
        
        */ 
        
        
import java.util.* ; 

public class Main
{
	public static void main(String[] args) { 
	    Scanner sc = new Scanner(System.in) ; 
	    String str = sc.nextLine () ; 
	    char [] reverse  = str.toCharArray() ; 
	    int left = 0 , right = str.length() - 1 ; 
	    while (left< right ) {  
	        char  temp = reverse[left ] ; 
	        reverse [left] = reverse[right  ] ; 
	        reverse[right ] = reverse[left ] ; 
	        reverse[right ] = temp ; 
	        left ++ ; 
	        right -- ;  } 
	        
	        if(reverse[left] == reverse[right]) { 
	             System.out.println("Palindrome ") ; 
	        
	    }
	    else { 
	         System.out.println("Not Palindrome ") ; 
	    } 
	    
	    String result = new String (reverse ) ; 
	    
	    
	        
		//System.out.println("Hello World");
	}
}
