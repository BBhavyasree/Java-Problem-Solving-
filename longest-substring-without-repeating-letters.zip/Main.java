/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/ 
import java.util.* ; 
import java.lang.* ; 

public class Main
{
	public static void main(String[] args) { 
	    Scanner sc = new Scanner (System.in) ; 
	    String str = sc.nextLine();     
	    char result =' ';  
	    int freq[] = new int [256] ; 
	    
	    int max = 0 ; 
	    for (int i = 0; i < str.length () ; i++) { 
	        char ch = str.charAt(i) ; 
	        freq [ch ] ++ ; 
	        if (freq[ch] > max) { 
	            max = freq[ch ] ; 
	            result = ch ; 
	        } 
	    } 
	    
		System.out.println(str); 
		System.out.println(result ); 
		System.out.println(max );
	}
}
