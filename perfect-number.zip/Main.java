/*Perfect Number ==> 
        EX:- 6 ----> 1+2+3==6
        i.e., Sum of all Factors, excluding itself*/
        import java.util.*;
        
        
public class Main
{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int s = sc.nextInt();
		int e =sc.nextInt();
		int count =0;
		int target = 0;
		
		
		
		for (int i =s; i<= e ; i++){
		    int res=0;
		    int n =i;
		    
		for( i=1; i<n; i++){
		    if(n%i==0){
		        res=res+i;
		        
		       
		        
		        //System.out.println(i);
		    }
		    
		    /*else{
		        System.out.println("No");
		    }
		    System.out.println(i);*/
		    
		}
		
		if (res==n) {
		    //System.out.println("Yes, it is a Perfect Number ");
		    count++;
		    System.out.println(count);
		    if (n==target) {
		        System.out.println(n);
		        
		    }
		        
		    }
		}
		
		/*else {
		    System.out.println("No, it is not a Perfect Number ");
		}*/
	}
}

