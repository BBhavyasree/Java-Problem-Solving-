/*Methods with Parameters 
Constructer will be the first method, to be executed 
It is a method, with special features , 
It is called automatically, called by the JVM Or The Compiler 
        -->> To initialize the Variables, we use the Constructor  
        */ 
        // Default Constructor Program 
        



 class Constructor1 { 
     String name  ; 
     int rollno  ; 
     double marks ; 
     void display() {
        System.out.println(name+" "+rollno+" "+marks) ;
}  
Constructor1() { 
     name = "Anand " ; 
     rollno = 123 ; 
     marks = 85.25 ;  
     System.out.println("Hello ") ;
    
}
}  
public class Main { 
    public static void main (String [] args ) { 
        Constructor1 ob = new Constructor1() ; 
        
        
        ob.display () ;  // Called using the Class Name (We Can Also Call Usin The Object, But Not Recommended ) ; 
    } 
}  



