/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/ 
import java.util.*;
import java.lang.*;


public class Main
{
	public static void main(String[] args) {
	    Scanner sc =new Scanner(System.in);
	    int a = sc.nextInt();
	    System.out.println("Enter the Number "); 
	    int count = 0; 
	    double sum =0; 
	    while (a>0){
	        count++;
	        int digit = a%10;
	        sum = sum + Math.pow(digit, count);
	        a=a/10;a
	        
	    }
	    
	    
	    System.out.println("Answer" +sum);
		
	}
}
