/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util. * ;
import java.lang.* ;


public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in) ;
		String str = sc.nextLine() ;

		char[] arr = str.toCharArray() ;


		for(int i = 0; i<str.length(); i++ ) {
			if ("aeiouAEIOU".indexOf(str.charAt(i)) != -1)  {
				str = str.replace(str.charAt(i), '@'  ) ;


			}



		}
		System.out.println(str);
		System.out.println(str);
	}
} 







// OR   




import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();

        for (char ch : str.toCharArray()) {
            if ("aeiouAEIOU".indexOf(ch) != -1) {
                str = str.replace(ch, '@');
            }
        }

        System.out.println(str);
    }
}

