import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the No. of Days n ");

        int n = sc.nextInt();
        /*if (n<=0)
        {
            System.out.println("Invalid");

        }
        if (n<=2)
        {
            System.out.println(50);

        }
        else{
            System.out.println(50+(n-2)*20);

        }*/
        
        if (n<=0)
        {
            System.out.println("Invalid");
            
        }
        else{
            if(n<=5)
            {
                System.out.println(n*2);
                
            }
            else if(n<= 10)
            {
                System.out.println(3*(n-5) +10);
                
                
            }
            else{
                System.out.println(10+15+(n-10)*5);
                
            }
        }
        
            
    }
}
        

    
    


    
    

