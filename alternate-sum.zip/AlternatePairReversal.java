import java.util.Scanner;

public class AlternatePairReversal {

    // Method to reverse alternate pairs in the array
    public static void reverseAlternatePairs(int[] arr) {
        for (int i = 0; i < arr.length - 1; i += 4) {
            swap(arr, i, i + 1); // Reverse the current pair
        }
    }

    // Helper method to swap two elements in an array
    public static void swap(int[] arr, int index1, int index2) {
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    // Method to print the array
    public static void printArray(int[] arr) {
        for (int num : arr)
            System.out.print(num + " ");
        System.out.println();
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take array size input
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();

        int[] arr = new int[n];

        // Take array elements input
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Print original array
        System.out.println("Original Array:");
        printArray(arr);

        // Reverse alternate pairs
        reverseAlternatePairs(arr);

        // Print modified array
        System.out.println("Modified Array:");
        printArray(arr);

        scanner.close();
    }
}
