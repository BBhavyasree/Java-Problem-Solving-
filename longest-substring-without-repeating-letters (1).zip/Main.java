/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/  
import java.util.* ; 
import java.lang . * ; 

public class Main
{
	public static void main(String[] args) { 
	    Scanner sc = new Scanner (System.in ) ; 
	    String str = sc.nextLine() ; 
	    String current = "" ; 
	    String longest = "" ; 
	    for ( int i = 0 ; i < str.length() ; i++) { 
	        char c =  str. charAt(i) ; 
	        if ( current.indexOf(c) != -1 ) { 
	            current = current.substring (current.indexOf(c) + 1 ) ; 
	        } 
	        current += c; 
	        if (current.length () > longest.length ()) { 
	            longest = current ; 
	        } 
	    } 
	    
		System.out.println(str); 
		System.out.println(longest ) ; 
		
	}
}
