/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Main
{
	public static void main(String[] args) {
	    Scanner sc =new Scanner(System.in);
	    
	    int n =sc.nextInt();
	      int sum =0; int s=0;
	    
	    int temp=n;
	    
	    while(n>0){
	        int f=1;
	       int d =n%10;
	        for(int i=1; i<=d; i++){
	            //int f=1;
	            f =f*i;
	            
	            
	        }sum+=f;
	        
	        n=n/10;
	   }//s = s+sum;
	   if(sum ==temp){
	       System.out.println("Yes,it is a Strong Number ");
	       
	   }else{
	       System.out.println("No");
	       
	   }
	    
		System.out.println(sum);
	}
}
