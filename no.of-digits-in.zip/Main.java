/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/ 
import java.util.*;

public class Main
{
	public static void main(String[] args) {
	    Scanner scc = new Scanner(System.in);
	    int a = scc.nextInt();
	    int count =0;
	    while(a>0){
	        a=a/10;
	        count++;
	        
	    }
	    
	    System.out.println("No.of Digits are:" +count);

		
	}
}
