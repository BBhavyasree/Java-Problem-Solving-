
import java.util.* ; 
public class Main {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in)    ; 
        int n = sc.nextInt( ) ; 
        
        // int arr[] = {3, 0, 1};
        int arr[] = new int[n]; 
        //int n = arr.length;  // n is actually 3, so range is 0 to 3 → missing 1 number

        int expectedSum = n * (n + 1) / 2;
        int actualSum = 0;
for (int i = 0; i < n; i++)   { 
    arr[i] = sc.nextInt() ; 
    } 
    
        for (int i = 0; i < n; i++) {
            actualSum += arr[i];
        }

        int missing = expectedSum - actualSum;

        System.out.println("Missing number is: " + missing);
    }
}

