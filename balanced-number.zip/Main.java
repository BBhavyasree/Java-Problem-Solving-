/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
import java.util. * ;
import java.lang.Math;

public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int rev =0 ;
		int prev = -1  ;
		int next = 0 ;

		while (n > 0 ) {
			if(n%2==0&& n  ) {
				int d = n%10;
				for (int i=)
					int d  = n% 10 ;
				rev = rev *10 +d  ;

				n =n/10;
				//System.out.println (rev) ;

			}
			int res = 0, first =0 ;
			boolean flag = true ;
			while (rev > 0)
			{
				int digit = rev % 10;
				if (flag) {
					first = digit ;
					res = digit ;
					flag = false ;
				}
				else {
					res = res * 10 + Math.abs (digit - first ) ;
					first = digit ;
				}

				rev = rev/10;

			}
			System.out.println(res ) ;











		}
	}




