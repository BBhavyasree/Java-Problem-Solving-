/*Amicaible Number 
         Factors 
284 ==> 1, 2, 4, 6, 8, 10, .....==> 1+2+4+6+8+10+... ==220
220 ==> 1.2.3.4, .....==> 1+2+3+4+... ==284 
*/


import java.util.*;

public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    int res =0;
	    int r =sc.nextInt();
	    int res1 =0;
	    
	    
	    
	    //d=n%10 ;
	    /*for (int j =0; j<r; j++) {
	        if(r%j==0){
		        res1=res1+j;
	    }System.out.println(res1);
	   } */
	   
	   for( int i=1; i<n; i++){
		    if(n%i==0){
		        res=res+i;
		        
		       }
	        }System.out.println(res);
	    	
	    	for( int i=1; i<r; i++){
		    if(r%i==0){
		        res1=res1+i;
		        
		        
		       
		        
		        //System.out.println(i);
		    }
	        }System.out.println(res1);
	   
	   
	   if(res ==r&& res1==n) {
	       System.out.println("Amicaible Numbers ");
	   
	   } 
	   else { 
	       System.out.println("No, it is Not An Amaicable Number ");
	    
	    
	
	}
    
}
}
	

