/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/ 
import java.util.*;
import java.lang.*;


public class Main
{
	public static void main(String[] args) {
	    Scanner sc =new Scanner(System.in);
	    int a = sc.nextInt();
	    System.out.println("Enter the Number "); 
	     
	    double sum =0; 
	    for (int i =0; i<= a ; i++) {
	        int count1 =0;
	    while (a>0){
	        double count = ((int) Math.log10(a)+1);
	        int digit = a%10;
	        sum = sum + Math.pow(digit, count);
	        a=a/10;
	        count--;
	    count1 ++;
	   } 
	   
	    
	    System.out.println("Answer" +count1);
	}	
	
}
}
