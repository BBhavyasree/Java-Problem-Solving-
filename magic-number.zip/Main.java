/*Magic Number ==> 
            10 ==> 1+ 0 == 1 */
            
import java.util.*;

public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int n = sc.nextInt();
		int  s=0;
		while (n>0 ) {
			s=0;


			while (n>10) {


				int  d =n%10;
				s =s+d;
				n= n/10;

			}
			n= s ;

		}

		// if ()
		if (s==1 ) {


			System.out.println("Yes");

		}
		else {
			System.out.println("No");
		}

	}
}


/*
import java.util.*;

public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int p1 = sc.nextInt();
		int p2 = sc.nextInt();
		while(p1>0) {
		    int d =p1%10;
		    if ()
		}
		*/
		
		
		
		
		
		

