/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*import java.util.* ;

public class Main
{
	public static void endZeroes(int n, int arr[]) {
		int temp ;
		int [] result = new int[n];
		int index = 0 ;


		for(int i =0; i<n; i++) {
			//for(int j=1; j<n ; j++)  {
			if ( arr[i] ==0) {
				/*temp = arr[i];
				arr[i] = arr[j] ;
				arr[j] = temp ; */
			/*	result[index++] = arr[i] ;

			}
			if (arr[i] != 0)  { 
			    
			// }
		}
	}
	public static void main(String [] args ) {
		Scanner sc = new Scanner(System.in) ;
		int n = sc.nextInt() ;
		int result []= new int[n] ;

		int arr[]= new int [n] ;
		for(int i =0; i < n ; i ++)  {
			arr[i] = sc.nextInt() ;

		}
		endZeroes(n, arr) ;


		System.out.print(Arrays.toString (result));
	}
}

*/
public class Main
{
	public static void Large(int n, arr[]) {
	    int large;
	    int small  ; 
	    
	    for(int i=0; i<n/2    ; i++  )  { 
	        for(int j =1; j< i+1 ; j++)  { 
	            if (arr[i] > arr[j] )  { 
	                large += arr[i]; 
	                
	            }
	        }
	    }
	    System.out.println(large);
	    for(int i=n/2; i<<n    ; i++  )  { 
	        for(int j =1; j< i+1 ; j++)  { 
	            if (arr[i] < arr[j] )  { 
	                small += arr[i]; 
	                
	        
	    }
	        }
	    }
	    	System.out.println(small);
	    	
	}	
	    
	    public static void main (String [] args ) {
	        Scanner sc = new Scanner(System.in)  ; 
	        int n = nextInt()  ; 
	        int [] arr = new int [n]  ; 
	        for (int i= 0  ; i< n ; i++)  { 
	           arr[] =  sc.nextInt  {}  ; 
	            
	        }
	        
	           
		System.out.println(small);
	}
	Large(n, arr)
		System.out.println(large - small );
}

