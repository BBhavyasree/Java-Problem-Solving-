/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.* ;
public class Main
{



	public static void sortArray(int n, int []arr) {

		int temp ;
		int mid = n/2 ;


		for(int i=0; i< n-1; i++)  {
			for(int j=i+1; j < mid; j++) {

				if (arr[i] > arr[j] ) {
					temp = arr[i] ;
					arr[i] = arr[j] ;
					arr[j] = temp ;
				}
			}
		
		for(int j =mid; j < n; j++)  {
			if(arr[i]<arr[j]) {
				temp = arr[i] ;
				arr[i] = arr[j] ;
				arr[j] = temp ;

			}
		}

		}
	}
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);

			int n = sc. nextInt() ;
			int [] arr = new int[n];
			// int [] b = new int[n];

			for(int i =0; i<n; i++) {
				arr[i] = sc.nextInt();
			}
			sortArray(n, arr) ;
			System.out.println(Arrays.toString(arr));
		}
	}



