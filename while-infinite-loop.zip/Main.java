/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;


public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int a = sc.nextInt();
	    int b = sc.nextInt();
	    int  sum = a+b;
	    System.out.println(sum);
	    int i=sc.nextInt();
	    
	    
	    while(i == 0){
	        System.out.println(sum);
	        
	    }
	    
	   
	}
}
//Infinite Loop 