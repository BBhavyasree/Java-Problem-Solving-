/*Methods with Parameters 
Constructer will be the first method, to be executed 
It is a method, with special features , 
It is called automatically, called by the JVM Or The Compiler 
        -->> To initialize the Variables, we use the Constructor  
        */ 
        // Default Constructor Program 
        



 import java.lang.reflect.Constructor ; 
 
  public class Constructor1 { 
     String name  ; 
     int rollno  ; 
     double marks ;  
     Constructor3 (String n, int r, double m ) { 
         name = n;
         rollno = r;
         marks = m ; 
     } 
     
     void display() { 
         
        System.out.println("Name : " +name) ; 
        System.out.println("Roll No. : " +rollno) ; 
        System.out.println("Marks : " +marks ) ;
}   
/* Constructor1() { 
     name = "Anand " ; 
     rollno = 123 ; 
     marks = 85.25 ;  
     System.out.println("Hello ") ;
    
}     */
}
public class Main { 
    public static void main (String [] args ) { 
        Constructor3 ob = new Constructor3() ; 
        
        
        ob.display () ;   
    } 
}  



