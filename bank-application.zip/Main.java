/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner (System.in);
	    int option = sc.nextInt();
	    
	    double amount = sc.nextInt();
	    
	    String Name = sc.nextLine();
	    System.out.println("Customer Name");
	    int AccountNo = sc.nextInt();
	    System.out.println("Account Number ");
        
	    
	    System.out.println("Initial Balance:");       
	    double InitBalance = sc.nextDouble();
	    
	    
	    
	    switch(option){
	        
	        case 1:
	            
	            
	            
	            
	        case 2:
	            System.out.println("Enter the Amount to Deposit ");
	            
	            
	            if ((amount > 0.0) && (amount <= 50000.0)){
	                System.out.println(InitBalance+amount);
	                
	            }
	            else{
	                System.out.println("Invalid Amount");
	                
	            }
	            break;
	            
	       case 3:
	           System.out.println("Enter the Amount to Withdraw  ");
	           if ((amount > 0.0)&&(amount <= 50000.0)){
	               System.out.println(InitBalance-amount);
	               
	           }
	           else{
	               System.out.println("Invalid Amount");
	               
	           }
	           break;
	           
	       case 4:
	           if (InitBalance > 0){
	               System.out.println("Balance is "+ InitBalance);
	               
	           }
	           break;
	       
	       
	           
	           
	           
	      
	           
	           
	            
	           
	            
	    }
		System.out.println("Hello World");
	}
}
