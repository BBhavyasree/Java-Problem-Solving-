/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/ 
 class Student1 { 
    String name ; 
    int rollno ; 
    double marks ; 
    void display() {
        System.out.println(name+" "+rollno+" "+marks) ;
} 
}  
public class Main { 
    public static void main (String [] args ) { 
        Student1 s1 = new Student1 () ; 
        s1.name = "Ravi" ; 
        s1.rollno = 123 ; 
        s1.marks = 58.25 ; 
        s1.display () ; 
    } 
} 


