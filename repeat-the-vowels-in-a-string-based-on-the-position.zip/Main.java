import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		String result = "";

		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);

			if ("aeiouAEIOU".indexOf(ch) != -1) {
				// Repeat vowel (i+1) times, based on position
				for (int j = 0; j <= i; j++) {
					result += ch;
				}
			} else {
				result += ch;
			}
		}

		System.out.println(result);
	}
}
