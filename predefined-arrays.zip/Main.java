/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.* ;

public class Main
{
	/*public static void sort(int n, int arr[]) {

	  } */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in) ;

		int n = sc.nextInt () ;
		int arr[] = new int[n] ;
		int m = sc.nextInt()  ;
		int b[] = new int[m]  ;

		for(int i =0; i< n ; i++)  {
			arr[i] = sc.nextInt();

		}
		for(int j =0; j< m ; j++)  {
			b[j] = sc.nextInt();

		}

		
		// Copy the Range of elements from one array to a new array 
		
		int [] copy = Arrays.copyOf(arr, 6) ;
		int [] rangecopy = Arrays.copyOfRange(arr, 1, 3)  ;
		
		// Fill a new Array, with the 
		
		int [] filled = new int[4]  ;       
		Arrays.fill(filled, 9) ;
		
		// Search a Key Element using the method, Binary Search 
		
		int index = Arrays.binarySearch(arr, 5 )          ;      
		 
		 // deepEquals Method, to compare two given 2D Arrays 
		
		

//	sort(n, arr) ;

		Arrays.sort(arr);


	//	System.out.println(arr);
	System.out.println("Sorted: " + Arrays.toString(arr));
	//	System.out.println("Equals: ? " + Arrays.equals(arr,b));

	//	System.out.println("Copy with length :  " + Arrays.toString(copy ));
	//	System.out.println("Copy with Range(1 to 2) :  " + Arrays.toString(rangecopy ));
     System.out.println("Fill an Array :  " + Arrays.toString(filled  ));   
     System.out.println(" Index of  5 :  " + index);   




	}
}
