/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {//throws IOException {
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Units Consumed");
	    int units = sc.nextInt();
	    
	    System.out.println("Customer Name ");
        String Name =sc.next();
        
        System.out.println("Customer ID ");
        int id = sc.nextInt();
        
        double rate;
        
        if ((units==0)|| (units <=100)){
            rate = units*1.50;
            System.out.println("Base Bill "+ rate);
            
        }
	    
	    else if((units ==101)||(units <= 200)){
	         rate = units*2.00;
	        System.out.println("Baase Bill "+ rate );
	    }
	    
	    else if((units ==201)||(units <= 300)){
	         rate = units*3.00;
	        System.out.println("Base Bill "+ rate );
	    }
	    
	    else if (units >= 301){
	        rate = units*5.00;
	        System.out.println("Base Bill "+ rate );
	        
	    }
	    double GST = rate*0.05;
	    double ServiceCharge = 
	    
	    
		System.out.println("Hello World");
	}
}
